package net.skhu.mapper;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import net.skhu.dto.Person;

@Mapper
public interface personMapper {

	@Select("SELECT * FROM category")
	static
	List<Person> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}