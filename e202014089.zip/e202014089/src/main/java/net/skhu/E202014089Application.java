package net.skhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E202014089Application {

	public static void main(String[] args) {
		SpringApplication.run(E202014089Application.class, args);
	}

}
