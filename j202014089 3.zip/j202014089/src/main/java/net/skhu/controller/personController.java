package net.skhu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import net.skhu.dto.Person;
import net.skhu.mapper.CategoryMapper;

@Controller
@RequestMapping("person")
public class personController {

	@Autowired
	CategoryMapper categoryMapper;

	@GetMapping("edit")
	public String edit(Model model) {
		model.addAttribute("student", new Person());
		return "person/edit";
	}

	@PostMapping("edit")
	public String edit(Model model, Person person) {
		// TODO: DB 저장 기능을 구현해야 함.
		model.addAttribute("message", "저장했습니다.");
		return "person/edit";
	}


}
