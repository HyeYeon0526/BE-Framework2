package net.skhu.dto;

import lombok.Data;

@Data
public class Person{
	int pid;
	String name;
	int categoryCode;
	String phone;
	String gender;
	String email;
	int title;

}